# navigation_node.py
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from geometry_msgs.msg import Twist

class NavigationNode(Node):
    def __init__(self):
        super().__init__('navigation_node')
        # Subscrição ao erro de navegação
        self.error_sub = self.create_subscription(Float32, 'lane/error', self.error_callback, 10)
        self.get_logger().info("Nó 'navigation_node' iniciado com sucesso!")
        # Publicador de comandos de movimento
        self.cmd_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        
        self.error = 0.0  # Inicializa o erro de navegação
    
    def error_callback(self, msg):
        self.error = msg.data
        self.get_logger().info(f"Erro recebido do tópico 'lane/error': {self.error}")

        self.navigate()

    def navigate(self):
        Kp = 0.1  #proporcional
        steer_command = -Kp * self.error
        cmd_msg = Twist()
        cmd_msg.angular.z = steer_command
        # Ajuste da velocidade
        cmd_msg.linear.x = 0.5  
        if abs(self.error) > 1:
            cmd_msg.linear.x = 0.3 
        self.cmd_pub.publish(cmd_msg)  # Publica o comando de movimento
        self.get_logger().info(f"Comando publicado no tópico 'cmd_vel': linear.x = {cmd_msg.linear.x}, angular.z = {cmd_msg.angular.z}")

def main(args=None):
    rclpy.init(args=args)
    node = NavigationNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
