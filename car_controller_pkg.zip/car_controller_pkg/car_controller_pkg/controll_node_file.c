#include <Servo.h>
#include "pitches.h"

const int ESC_PIN = 9;
const int SERVO_PIN = 10;
const int TRIGGER_PIN = 12;
const int ECHO_PIN = 13;
const int BUZZER_PIN = 7;
const int LED_PIN = 6; 
long duration;
int distance;

Servo servo;

int led_fast = 100;  // Tempo curto para piscar LED rapidamente (em milissegundos)
int led_slow = 1000;  // Tempo longo para piscar LED lentamente (em milissegundos)

void setup() {
  Serial.begin(115200);
  servo.attach(SERVO_PIN);
  servo.write(90);  // Posição neutra do servo

  // Configura os pinos para o ESC e outros dispositivos
  pinMode(ESC_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);  // Configura o pino do LED
  analogWrite(ESC_PIN, 0);   // Inicializa o ESC com valor 0 (desligado)
  
  pinMode(TRIGGER_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  pinMode(BUZZER_PIN, OUTPUT); // Configura o pino do buzzer
}

void blinkLed(int delayTime) {
  // Função para piscar o LED de acordo com o tempo fornecido
  digitalWrite(LED_PIN, HIGH);
  delay(delayTime);  // Tempo do delay para controlar a velocidade do piscar
  digitalWrite(LED_PIN, LOW);
  delay(delayTime);  // Tempo do delay para controlar a velocidade do piscar
}

void signalMotorRunning() {
  digitalWrite(LED_PIN, HIGH);  // LED aceso
}

void signalMotorStopped() {
  // Apaga o LED para sinalizar que o motor parou
  digitalWrite(LED_PIN, LOW);   // LED apagado
}

void get_distance() {
  // Lê a distância com o sensor ultrassônico
  digitalWrite(TRIGGER_PIN, LOW);
  delayMicroseconds(2);  
  digitalWrite(TRIGGER_PIN, HIGH);
  delayMicroseconds(10); 
  digitalWrite(TRIGGER_PIN, LOW);
  
  duration = pulseIn(ECHO_PIN, HIGH);  // Lê o tempo de duração do pulso de volta
  distance = duration * 0.0344 / 2;  // Converte o tempo em distância (em cm)
}

void freio_emergencia() {
  analogWrite(ESC_PIN, 0);  // Para o motor
  servo.write(90);  // Coloca o servo na posição neutra (não vira)
  Serial.println("Objeto muito próximo! Freio de emergência ativado.");
  signalMotorStopped();  // Apaga o LED quando o motor for parado
  alarmBuzzer();  // Aciona o alarme do buzzer
}

void alarmBuzzer() {
  // Função para tocar um alarme com o buzzer
  for (int i = 0; i < 4; i++) {  // Toca o alarme 5 vezes
    tone(BUZZER_PIN, 100);  // Frequência do som (1000 Hz)
    blinkLed(led_fast);       // Pisca o LED rapidamente enquanto o alarme toca
    delay(10);               // Duração do som
    noTone(BUZZER_PIN);       // Para o som
    delay(50);               // Intervalo entre os sons
  }
}

void loop() {
  get_distance();  // Chama a função para medir a distância

  if (distance < 10) { // Distância de 10 cm ou menos
    freio_emergencia(); // Ativa freio de emergência
  } else {
    // Lê os comandos recebidos via serial (do ROS 2, por exemplo)
    if (Serial.available() > 0) {
      String command = Serial.readStringUntil('\n'); // Lê o comando enviado
      int commaIndex = command.indexOf(',');

      if (commaIndex > 0) {
        // Extrai os valores de velocidade do motor e ângulo do servo
        int motorSpeed = command.substring(0, commaIndex).toInt();
        int steeringAngle = command.substring(commaIndex + 1).toInt();

        // Controle do ESC e Servo
        analogWrite(ESC_PIN, motorSpeed); // Envia valor PWM para ESC
        servo.write(steeringAngle); // Define o ângulo do servo

        if (motorSpeed > 0) {  // Se o motor estiver ligado
          signalMotorRunning();  // Acende o LED para indicar que o motor está em funcionamento
          blinkLed(led_slow);    // Pisca o LED lentamente quando o motor está funcionando
        } else {
          signalMotorStopped();  // Apaga o LED para indicar que o motor está parado
        }
      }
    }
  }
}
