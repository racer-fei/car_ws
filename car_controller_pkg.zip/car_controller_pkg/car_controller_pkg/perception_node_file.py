import rclpy
from rclpy.node import Node
import cv2 as cv
import numpy as np
from std_msgs.msg import Float32
from cv_bridge import CvBridge

class LaneDetectionNode(Node):
    def __init__(self):
        super().__init__('perception_node')
        self.bridge = CvBridge()

        # Publica o erro de navegação
        self.error_pub = self.create_publisher(Float32, 'lane/error', 10)

        # Configuração da webcam
        self.cap = cv.VideoCapture(0)  # Abre a webcam (0 é geralmente a primeira webcam)
        if not self.cap.isOpened():
            self.get_logger().error("Não foi possível acessar a webcam!")
            return
        # Mensagem de sucesso ao iniciar o nó
        self.get_logger().info("Nó 'perception_node' iniciado com sucesso!")

    def crop_left_half(self, frame):
        height, width = frame.shape[:2]
        return frame[:, :width // 2]

    def roi_bottom_half(self, frame):
        height, width = frame.shape[:2]
        return frame[height // 2:, :]

    def calculate_angle(self, x1, y1, x2, y2):
        delta_y = y2 - y1
        delta_x = x2 - x1
        angle = np.degrees(np.arctan2(delta_y, delta_x))
        return angle

    def process_frame(self, frame):
        # Pré-processamento da imagem
        frame = self.crop_left_half(frame)
        frame = self.roi_bottom_half(frame)
        frame_copy = frame.copy()

        gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
        blurred = cv.GaussianBlur(gray, (7, 7), 0)
        edges = cv.Canny(blurred, 50, 150)

        kernel = np.ones((3, 3), np.uint8)
        edges = cv.dilate(edges, kernel, iterations=1)
        edges = cv.erode(edges, kernel, iterations=1)

        lines = cv.HoughLinesP(edges, 1, np.pi / 180, 50, minLineLength=100, maxLineGap=5)
        
        if lines is not None:
            left_lines, right_lines = [], []
            for x1, y1, x2, y2 in lines[:, 0]:
                angle = self.calculate_angle(x1, y1, x2, y2)
                if abs(angle) > 5:  # Ignora ângulos muito pequenos
                    if x1 < frame.shape[1] // 2:
                        left_lines.append((x1, y1, x2, y2))
                    else:
                        right_lines.append((x1, y1, x2, y2))

            # Desenha as linhas detectadas na imagem original (copiada)
            for x1, y1, x2, y2 in left_lines + right_lines:
                cv.line(frame_copy, (x1, y1), (x2, y2), (0, 255, 0), 2)  # Linhas verdes

            if left_lines and right_lines:
                left_center = np.mean([x1 for x1, _, _, _ in left_lines])
                right_center = np.mean([x2 for _, _, x2, _ in right_lines])
                center_line = (left_center + right_center) / 2
                error = center_line - (frame.shape[1] / 2)

                # Publica o erro de navegação
                self.error_pub.publish(Float32(data=error))
                self.get_logger().info(f"Erro publicado: {error}")

        cv.imwrite("/home/roboracer/imgs/frame_copy.jpg", frame_copy)
        #cv.waitKey(1)  # Permite que a janela de imagem seja atualizada

    def run(self):
        while rclpy.ok():
            ret, frame = self.cap.read()  # Lê o próximo frame da webcam
            if not ret:
                self.get_logger().error("Falha ao capturar frame da webcam!")
                break

            self.process_frame(frame)  # Processa o frame

    def stop(self):
        self.cap.release()  # Libera a câmera quando o programa terminar

def main(args=None):
    rclpy.init(args=args)
    node = LaneDetectionNode()

    node.run()

    # Libera recursos ao encerrar
    node.stop()
    node.destroy_node()
    rclpy.shutdown()
    cv.destroyAllWindows()  # Fecha todas as janelas OpenCV ao encerrar

if __name__ == '__main__':
    main()
