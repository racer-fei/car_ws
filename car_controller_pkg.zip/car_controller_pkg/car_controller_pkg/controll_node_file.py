import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import serial
import time

class ControlNode(Node):
    def __init__(self):
        super().__init__('controll_node')

        # Defina a porta serial para se comunicar com o Arduino
        self.arduino_port = '/dev/ttyACM0'  # Alterar conforme necessário
        self.baud_rate = 115200  # Definir taxa de transmissão

        try:
            # Abre a comunicação serial com o Arduino
            self.arduino = serial.Serial(self.arduino_port, self.baud_rate)
            self.get_logger().info(f'Conectado ao Arduino na porta {self.arduino_port}')
            time.sleep(2)  # Atraso para o Arduino inicializar
        except Exception as e:
            self.get_logger().error(f'Erro ao conectar com o Arduino: {e}')
            raise

        # Cria um subscriber para o tópico 'cmd_vel'
        self.create_subscription(
            Twist,
            'cmd_vel',
            self.cmd_vel_callback,
            10
        )

    def cmd_vel_callback(self, msg):
        """
        Callback para processar as mensagens recebidas no tópico 'cmd_vel'.
        Converte as mensagens de velocidade linear e angular para comandos 
        que serão enviados para o Arduino via serial.
        """
        linear_speed = msg.linear.x
        angular_speed = msg.angular.z

        # Converte as velocidades para os valores correspondentes para o ESC e servo
        motor_speed = self.map_speed(linear_speed)
        steering_angle = self.map_steering(angular_speed)

        # Envia os comandos para o Arduino
        self.send_to_arduino(motor_speed, steering_angle)

    def send_to_arduino(self, motor_speed, steering_angle):
        """
        Envia os comandos de velocidade do motor e direção para o Arduino via serial.
        """
        # Formata os comandos em uma string para enviar via serial
        command = f'{motor_speed},{steering_angle}\n'

        # Envia a string para o Arduino
        self.arduino.write(command.encode())

        self.get_logger().info(f'Comando enviado para o Arduino: {command.strip()}')

    def map_speed(self, linear_speed):
        """
        Mapeia a velocidade linear (0 a 0.5) para um valor PWM (0 a 255) para o ESC.
        """
        # A velocidade linear no ROS é de 0 a 0.5, o PWM do ESC varia de 0 a 255
        pwm = int(linear_speed * 255)
        return max(0, min(255, pwm))

    def map_steering(self, angular_speed):
        """
        Mapeia a velocidade angular (de -1 a 1) para um valor de ângulo (0 a 180) para o servo.
        """
        angle = int((angular_speed + 1) * 90)  # Converte de -1..1 para 0..180
        return max(0, min(180, angle))

def main(args=None):
    rclpy.init(args=args)

    # Cria o nó ROS 2 de controle
    control_node = ControlNode()

    # Executa o nó
    rclpy.spin(control_node)

    # Finaliza quando o nó for destruído
    control_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
