import cv2
import numpy as np

def detect_lines(image):
    """Detecta linhas em uma imagem usando a Transformada de Hough."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=100, minLineLength=50, maxLineGap=10)

    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            cv2.line(image, (x1, y1), (x2, y2), (0, 255, 0), 2)

    return image

def main():
    # Inicializa a captura de vídeo da webcam
    cap = cv2.VideoCapture(0)  # Use 0 para a webcam padrão

    if not cap.isOpened():
        print("Erro ao abrir a webcam.")
        return

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Erro ao capturar o vídeo.")
            break

        processed_frame = detect_lines(frame)
        cv2.imshow('Detecção de Linhas', processed_frame)

        key = cv2.waitKey(1)
        if key == 27:  # Pressione 'Esc' para sair
            break

    # Libera os recursos
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
