import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2 as cv
import numpy as np
from std_msgs.msg import Float32

class LaneDetectionNode(Node):
    def __init__(self):
        super().__init__('lane_detection')
        self.bridge = CvBridge()
        self.image_sub = self.create_subscription(Image, 'camera/image_raw', self.image_callback, 10)
        self.error_pub = self.create_publisher(Float32, 'lane/error', 10)

    def crop_left_half(self, frame):
        height, width = frame.shape[:2]
        return frame[:, :width // 2]

    def roi_bottom_half(self, frame):
        height, width = frame.shape[:2]
        return frame[height // 2:, :]

    def calculate_angle(self, x1, y1, x2, y2):
        delta_y = y2 - y1
        delta_x = x2 - x1
        angle = np.degrees(np.arctan2(delta_y, delta_x))
        return angle

    def process_frame(self, frame):
        frame = self.crop_left_half(frame)
        frame = self.roi_bottom_half(frame)

        gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
        blurred = cv.GaussianBlur(gray, (7, 7), 0)
        edges = cv.Canny(blurred, 50, 150)

        kernel = np.ones((3, 3), np.uint8)
        edges = cv.dilate(edges, kernel, iterations=1)
        edges = cv.erode(edges, kernel, iterations=1)

        lines = cv.HoughLinesP(edges, 1, np.pi / 180, 50, minLineLength=100, maxLineGap=5)
        if lines is not None:
            left_lines, right_lines = [], []
            for x1, y1, x2, y2 in lines[:, 0]:
                angle = self.calculate_angle(x1, y1, x2, y2)
                if abs(angle) > 5:
                    if x1 < frame.shape[1] // 2:
                        left_lines.append((x1, y1, x2, y2))
                    else:
                        right_lines.append((x1, y1, x2, y2))

            if left_lines and right_lines:
                left_center = np.mean([x1 for x1, _, _, _ in left_lines])
                right_center = np.mean([x2 for _, _, x2, _ in right_lines])
                center_line = (left_center + right_center) / 2
                error = center_line - (frame.shape[1] / 2)

                # Publica o erro de navegação
                self.error_pub.publish(Float32(data=error))

        return frame

    def image_callback(self, msg):
        frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        processed_frame = self.process_frame(frame)

def main(args=None):
    rclpy.init(args=args)
    node = LaneDetectionNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()